<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Prueba de caca, laboratorio Xamarin</title>
  </head>
  <body>
    INICIAR SESION
    <form class="" action="login.php" method="post">
        <div class="">
            <div class="">
                Email prro del mal
                <input type="email" name="email">
            </div>
            <div class="input-field col s12 m12">
                Password prro del mal
                <input  type="password" name="password">
            </div>
            <input type="submit" name="input" value="Fuga alv" >
    </form>
    REGISTRAR
    <form action="register.php" method="post">
        <div>
            Nombre prro del mal
            <input type="text" name="name">
        </div>
        <div>
          Email prro del mal
            <input type="email" name="email">
        </div>
        <div>
          Password prro del mal
            <input type="password" name="password">
        </div>
        Vamonos alv prro
        <input type="submit" name="input">
    </form>
  </body>
</html>
