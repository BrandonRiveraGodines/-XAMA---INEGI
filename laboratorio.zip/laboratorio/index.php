<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Prueba de caca, laboratorio Xamarin</title>
  </head>
  <body>
    INICIAR SESION
    <form class="" action="login/index.php" method="post">
        <div class="">
            <div class="">
                Email prro del mal
                <input type="email" name="email">
            </div>
            <div class="input-field col s12 m12">
                Password prro del mal
                <input  type="password" name="password">
            </div>
            <input type="submit" name="input" value="Fuga alv" >
    </form>
    <br><br>
    REGISTRAR
    <form action="register/index.php" method="post">
        <div>
            Nombre prro del mal
            <input type="text" name="name">
        </div>
        <div>
          Email prro del mal
            <input type="email" name="email">
        </div>
        <div>
          Password prro del mal
            <input type="password" name="password">
        </div>
        Vamonos alv prro
        <input type="submit" name="input">
    </form>
    <br><br>
    SUBIR IMAGEN
    <form action="products/index.php" method="POST">
      <div>
        Email prro del mal
        <input type="text" name="email">
      </div>
      <div>
        Mensaje
        <input type="text" name="mensaje">
      </div>
      <div>
        BAse 64 prro del mal
        <input type="text" name="fotografia">
      </div>
      Actualiza prro del mal
      <input type="submit" name="input" value="Actualiza prrrooooo">
    </form>
  </body>
</html>
