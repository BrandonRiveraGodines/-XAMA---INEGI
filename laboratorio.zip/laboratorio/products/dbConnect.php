<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB', 'laboratorio');

$con = mysqli_connect(HOST, USER, PASS, DB) or die ('No se puede conectar a la base de datos');
?>
