<?php
  if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $video_name = $_FILES["video"]["name"];
    $video_size = $_FILES["video"]["size"];
    $video_type = $_FILES["video"]["type"];
    $video_file = $_FILES["video"]["tmp_name"];
    require_once('dbConnect.php');
    $sql = "SELECT id FROM laboratorio ORDER BY id ASC";
    $res = mysqli_query($con, $sql);
    $id = 1;
    while($row = mysqli_fetch_array($res)){
      $id = $row['id'];
    }
    $path = "uploads/$id.mp4";
    $actualpath = "http://192.168.0.5/laboratorio/videos/$path";
    $email = substr($video_name, 0, -4);
    $sql = "UPDATE laboratorio SET video_direccion = '$actualpath' WHERE email = '$email'";
    echo $sql."<br>";
    if(mysqli_query($con, $sql)){
      //copy($video_file, $path);
      //file_put_contents($path, base64_decode($fotografia));
      //file_put_contents($path, $video_file);
      move_uploaded_file($video_file, $path);
      echo "Succesful";
    } else {
      echo mysqli_error($con);
    }
    mysqli_close($con);
  } else {
    echo "Error";
  }
?>
